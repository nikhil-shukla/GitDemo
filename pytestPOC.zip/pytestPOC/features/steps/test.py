from behave import *
from selenium import webdriver

@given("Open browser")
def open_browser(context):
    context.driver = webdriver.Chrome()
    context.driver.maximize_window()
    context.driver.get("https://www.google.com")
    
@then("Assert")   
def assertion(context):
    title = context.driver.title
    print(title)
    assert title == "Google"
    context.driver.quit()
