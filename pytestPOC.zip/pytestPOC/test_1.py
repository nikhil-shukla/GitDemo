from selenium import webdriver
import pytest

def test_loadWeb():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("https://www.google.com")
    title = driver.title
    print(title)
    assert title == "Google"
    driver.quit()

def test_loadFb():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("https://www.facebook.com")
    title = driver.title
    print(title)
    assert title == "Facebook"
    driver.quit()